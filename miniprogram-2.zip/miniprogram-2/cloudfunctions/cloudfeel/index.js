// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env:"cloud1-3girwzgbe691903f"
})

// 云函数入口函数
exports.main = async (event, context) => {
  if(event.choose=="feel"){
    return await cloud.database().collection('user')
    .doc(event.id)
    .update({
      data:{
           feel:event.feel
      }
    })
    .then(res=>{
      console.log('更新成功',res)
      return 
    })
    .catch(res=>{
      console.log('更新失败')
      return 
    })
  }else if(event.choose=="collect"){
    return await cloud.database().collection('books')
    .doc(event.id)
    .update({
      data:{
           book_stars:event.collect
      }
    })
    .then(res=>{
      console.log('更新成功',res)
      return 
    })
    .catch(res=>{
      console.log('更新失败')
      return 
    })
  }else if(event.choose=="viewcounts"){
    return await cloud.database().collection('books')
    .doc(event.id)
    .update({
      data:{
           view_counts:event.view_counts
      }
    })
    .then(res=>{
      console.log('更新成功',res)
      return 
    })
    .catch(res=>{
      console.log('更新失败')
      return 
    })
  }else if(event.choose=="collection"){
    return await cloud.database().collection('user_stars')
    .doc(event.openid)
    .update({
      data:{
          booksId:event.collection
      }
    })
    .then(res=>{
      console.log('更新成功',res)
      return 
    })
    .catch(res=>{
      console.log('更新失败')
      return 
    })
  }
  else if(event.choose=="hot"){
    return await cloud.database().collection('books')
    .doc(event.id)
    .update({
      data:{
          hot:event.hot
      }
    })
    .then(res=>{
      console.log('更新成功',res)
      return 
    })
    .catch(res=>{
      console.log('更新失败')
      return 
    })
  }
  else if(event.choose=="recommand"){
    return await cloud.database().collection('books')
    .doc(event.id)
    .update({
      data:{
          recommand:event.recommand
      }
    })
    .then(res=>{
      console.log('更新成功',res)
      return 
    })
    .catch(res=>{
      console.log('更新失败')
      return 
    })
  }
}