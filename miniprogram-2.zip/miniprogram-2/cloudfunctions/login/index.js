// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  //API调用都保持和云函数当前所在环境一致
  env:"cloud1-3girwzgbe691903f"
})

// 云函数入口函数
exports.main = async (event, context) => {
  console.log(event)
  console.log(context)
  // 可执行其他自定义逻辑
  // console.log的内容可以在云开发云函数调用日志查看
  // 获取WX context(微信调用上下文),包括OPENID,AppID以及UNIONID(需满足UNIONID获取条件等)信息
  const wxContext = cloud.getWXContext()

  return {
    event,
    openid: wxContext.OPENID,
    appid: wxContext.APPID,
    unionid: wxContext.UNIONID,
    env:wxContext.ENV,
  }
}