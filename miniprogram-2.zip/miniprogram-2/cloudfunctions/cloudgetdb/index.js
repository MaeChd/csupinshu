// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  if(event.db=="books"){
  return await cloud.database().collection('books').doc(event.id).get()
 }else if(event.id=="userstars"){
  return await cloud.database().collection('user_stars').doc(event.openid).get()
 }
}