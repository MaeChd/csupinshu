// app.js
var user_info_openid =""
App({
   //用户与管理员身份的登录判断
   getOpenId:function(){
       wx.cloud.init();
       wx.cloud.callFunction({
            name:"login",
       })
       .then(res=>{
              console.log("这是res",res.result)
              //res.result里面只有openid和appid
                // this.globalData.userInfo.openId =res.result.openid;
                // console.log(this.globalData.userInfo.openId)
                user_info_openid=res.result.openid;
               this.isAdmin();
              }).catch(res=>{
              console.log(err);
              wx.showModal({
                title:'提示',content:'获取用户信息失败，请重试',
              })
            })
            // vcomplete:()=>{ }
   },
   //判断是否为管理员
  isAdmin:function(){
         var that =this;
          //通过openid获取admin表中的数据
          console.log("user_info_openid",user_info_openid)
        this.getDBPromise({
             db_name:this.DB_NAME.db_admin,
             entity:{
                 openId:user_info_openid
             }
        }).then(res=>{
          wx.hideLoading();
          console.log("res.data",res.data)
          if(res.data.length>0){
            this.globalData.isAdmin =true;
            //跳转到admin管理界面
            wx.showModal({
              title:'提示',content:'检测到您是管理员，是否跳转页面?',
              success:function(res){
                if(res.confirm){
                  console.log("跳转到管理员页面")
                  wx.redirectTo({
                    url: '/pages/admin/index/index',
                  })
                }else if(res.cancel){
                  setTimeout(wx.switchTab,500,({url:"/pages/index/index"})
                  );
                }
              },
              fail:function(res){console.error(res)},
            })
          }
        }).catch(res=>{
              
        })
  }, 
  //数据库查询操作 
  getDBPromise:function(e){
      var db_name =e.db_name;
      var entity =e.entity;
      const db =wx.cloud.database();
      return db.collection(db_name).where(entity).get();
  },
  onLaunch() {
    if(!wx.cloud){
      console.log('请使用2.2.3或以上的基础库以使用云开发相关功能')
    }else{
      wx.cloud.init(
        //env参数说明：
        //env决定小程序发起的云开发调用会默认请求哪个云环境的资源
        //环境的id可打开云控制台查看
        //如不慎则使用默认环境（第一个创建的环境）
        //env:'my-env-id',
        {
          env:"cloud1-3girwzgbe691903f",
          traceUser:true
         }
      )
    }
    // // 展示本地存储能力
    //  const logs = wx.getStorageSync('logs') || []
    // logs.unshift(Date.now())
    // wx.setStorageSync('logs', logs)

    //  // 登录
    //  wx.login({
    //    success: res => {
    //      // 发送 res.code 到后台换取 openId, sessionKey, unionId
    //    }
    //  })

      var that= this
      wx.cloud.callFunction({
        name:'getopenid',
        success(res){
            that.globalData.openid=res.result.openid
            wx.setStorageSync('openid', res.result.openid)
        }
      })
   },
   DB_NAME:{
      db_admin:"admin",
      db_user:"user"
   },
   globalData: {
    isAdmin:null,
    userInfo:null,
    // openId:"",
    // ip:"",
    // currentLocation:"",
    // avatarUrl:"",
    // nickName:""
    openid:null
   }
})
