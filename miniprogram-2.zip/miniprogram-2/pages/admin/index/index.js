// pages/admin/index/index.js
const db=wx.cloud.database();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    hotIcon:"../../../images/热门.png",
    reIcon:"../../../images/推荐.png",
    hotedIcon:"../../../images/热门1.png",
    reedIcon:"../../../images/推荐1.png",
    cateId:0,//书籍当前选中的类别
    categories:[
      {cateName:'全部',categoryId:0},
      {cateName:'经济类',categoryId:1},
      {cateName:'社会类',categoryId:2},
      {cateName:'历史类',categoryId:3},
      {cateName:'哲学类',categoryId:4},
      {cateName:'科学类',categoryId:5},
      {cateName:'心理学类',categoryId:6},
      {cateName:'其他',categoryId:7},
    ],
    bookList:[],
  },

  //点击设为热门
  handlehot(e){
     console.log(e.currentTarget.dataset.id)//获取所点击的书籍在云服务器的id
     let ID=e.currentTarget.dataset.id
     let hot=e.currentTarget.dataset.hot
     wx.showToast({
      title: hot?"取消热门成功":"设为热门成功",
     })
     hot=!hot  
     wx.cloud.callFunction({
       name:"cloudfeel",
       data:{
         choose:"hot",
         id:ID,
         hot:hot
       }
     }).then(res=>{
       console.log("热门更新成功",res)
     })
     .catch(res=>{
       console.log("热门更新失败",res)
     })
  },
  //点击设为推荐
  handlere(e){
     console.log(e)
     let ID=e.currentTarget.dataset.id
     let recommand=e.currentTarget.dataset.recommand
     wx.showToast({
      title: recommand?"取消推荐成功":"设为推荐成功",
    })
     recommand=!recommand
     wx.cloud.callFunction({
      name:"cloudfeel",
      data:{
        choose:"recommand",
        id:ID,
        recommand:recommand
      }
    }).then(res=>{
      console.log("推荐更新成功",res)

    })
    .catch(res=>{
      console.log("推荐更新失败",res)
    })
  },
  switchLeftTab:function(e){
    if(e.target.dataset.id!=0){
       wx.cloud.database().collection('books').where({
         classifyId:e.target.dataset.id,
       })
       .get()
       .then(res=>{
            console.log("书籍请求成功",res)
            this.setData({
              cateId:e.target.dataset.id,
              bookList:res.data,
              bookhotif:res.data.hot,
              bookreif:res.data.recommand
            })
       })
      }
      else if(e.target.dataset.id==0){
        wx.cloud.database().collection('books')
        .get()
        .then(res=>{
             console.log("书籍请求成功",res)
             this.setData({
               cateId:e.target.dataset.id,
               bookList:res.data,
               bookhotif:res.data.hot,
               bookreif:res.data.recommand
             })
        })
      }
       wx.showToast({
         title: '加载中...',icon:'loading',duration:500
       })
      //  this.getBooks(this.limit,this.skip);
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.cloud.database().collection('books')
    .get()
    .then(res=>{
         console.log("书籍请求成功0",res)
         this.setData({
           bookList:res.data,
         })
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.showNavigationBarLoading({
            
    })
    setTimeout(function(){
     wx.hideNavigationBarLoading({
     })
    },2000)
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
       wx.showLoading({
         title: '加载中',
       })
       setTimeout(function(){
         wx.hideLoading({})
       },2000)
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})