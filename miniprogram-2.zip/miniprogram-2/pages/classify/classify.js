// pages/classify/classify.js
var cateids="";
// var total=0;
var app = getApp();

Page({
  /**
   * 页面的初始数据
   */
 
  data: {
    booklen:0,
    total:0,
    cateId:0,
    categories:[
      {cateName:'全部',categoryId:0},
      {cateName:'心理学类',categoryId:1},
      {cateName:'社会类',categoryId:2},
      {cateName:'历史类',categoryId:3},
      {cateName:'哲学类',categoryId:4},
      {cateName:'科学类',categoryId:5},
      {cateName:'经济类',categoryId:6},
      {cateName:'其他',categoryId:7},
    ],
       bookList0:[],
       bookList1:[],
       bookList2:[],
       bookList3:[],
       bookList4:[],
       bookList5:[],
       bookList6:[],
       bookList7:[],
   },
   
//云函数请求数据+分页处理（5个一组）
getData(){
      wx.cloud.callFunction({
        name:'getData',
      })
      .then(res=>{
        console.log('获取成功',res)
        this.setData({
          bookList:res.result.data
        })
      })
      .catch(res=>{
        console.log('获取失败',res)
      })
},
//判断是哪个类别
judge(cateid){
    var len
    if(cateid==0){ len=this.data.bookList0.length}
    else if(cateid==1){  len=this.data.bookList1.length}
    else if(cateid==2){  len=this.data.bookList2.length}
    else if(cateid==3){  len=this.data.bookList3.length}
    else if(cateid==4){  len=this.data.bookList4.length}
    else if(cateid==5){  len=this.data.bookList5.length}
    else if(cateid==6){ len=this.data.bookList6.length}
    else if(cateid==7){  len=this.data.bookList7.length}
    return len
},
//设置该类别的list
setlist(cateid){
    if(cateid==0){
      this.getlistall()
      
    }
    else if(cateid==1){
      this.getDatabooks1()
      
    }
    else if(cateid==2){ 
      this.getDatabooks2()
     
    }
    else if(cateid==3){
       this.getDatabooks3()
      
    }
    else if(cateid==4){ 
       this.getDatabooks4()
     
    }
    else if(cateid==5){ 
       this.getDatabooks5()
     
   }
    else if(cateid==6){
       this.getDatabooks6()
      
   }
    else if(cateid==7){
       this.getDatabooks7()
      
    }
   
},
//数据库请求非云函数
//经济类
getDatabooks1(){
    let lens=this.judge(this.data.cateId)
    wx.cloud.database().collection('books')
    .skip(lens)
    .limit(5)
    .where({
      classifyId :1
    })
    .get()
    .then(res=>{
      console.log('请求成功',res)
      console.log(this.data.cateId)
      this.setData({
      bookList1:this.data.bookList1.concat(res.data),
      booklen:lens+5
      })
    })
    .catch(res=>{
      console.log('请求失败',res)
    })
},
//社会类
getDatabooks2(){
    let lens=this.judge(this.data.cateId)
    wx.cloud.database().collection('books')
    .skip(lens)
    .limit(5)
    .where({
      classifyId :2
    })
    .get()
    .then(res=>{
      console.log('请求成功',res)
      console.log(this.data.cateId)
      this.setData({
      bookList2:this.data.bookList2.concat(res.data),
      booklen:lens+5
      })
    })
    .catch(res=>{
      console.log('请求失败',res)
    })
},
//历史类
getDatabooks3(){
    let lens=this.judge(this.data.cateId)
    wx.cloud.database().collection('books')
    .skip(lens)
    .limit(5)
    .where({
      classifyId :3
    })
    .get()
    .then(res=>{
      console.log('请求成功',res)
      console.log(this.data.cateId)
      this.setData({
      bookList3:this.data.bookList3.concat(res.data),
      booklen:lens+5
      })
    })
    .catch(res=>{
      console.log('请求失败',res)
    })
},
//哲学类
getDatabooks4(){
    let lens=this.judge(this.data.cateId)
    wx.cloud.database().collection('books')
    .skip(lens)
    .limit(5)
    .where({
      classifyId :4
    })
    .get()
    .then(res=>{
      console.log('请求成功',res)
      console.log(this.data.cateId)
      this.setData({
      bookList4:this.data.bookList4.concat(res.data),
      booklen:lens+5
      })
    })
    .catch(res=>{
      console.log('请求失败',res)
    })
},
//科学类
getDatabooks5(){
    let lens=this.judge(this.data.cateId)
    wx.cloud.database().collection('books')
    .skip(lens)
    .limit(5)
    .where({
      classifyId :5
    })
    .get()
    .then(res=>{
      console.log('请求成功',res)
      console.log(this.data.cateId)
      this.setData({
      bookList5:this.data.bookList5.concat(res.data),
      booklen:lens+5
      })
    })
    .catch(res=>{
      console.log('请求失败',res)
    })
},
//心理学类
getDatabooks6(){
   let lens=this.judge(this.data.cateId)
    wx.cloud.database().collection('books')
    .skip(lens)
    .limit(5)
    .where({
      classifyId :6
    })
    .get()
    .then(res=>{
      console.log('请求成功',res)
      console.log(this.data.cateId)
      this.setData({
      bookList6:this.data.bookList6.concat(res.data),
      booklen:lens+5
      })
    })
    .catch(res=>{
      console.log('请求失败',res)
    })
},
getDatabooks7(){
    let lens=this.judge(this.data.cateId)
    wx.cloud.database().collection('books')
    .skip(lens)
    .limit(5)
    .where({
      classifyId :7
    })
    .get()
    .then(res=>{
      console.log('请求成功',res)
      console.log(this.data.cateId)
      this.setData({
      bookList7:this.data.bookList7.concat(res.data),
      booklen:lens+5
      })
    })
    .catch(res=>{
      console.log('请求失败',res)
    })
},
   //全部
getlistall(){
    let lens=this.data.bookList0.length
    wx.cloud.database().collection('books')
    .skip(lens)
    .limit(5)
    .get()
    .then(res=>{
      console.log('请求成功',res)
      console.log(this.data.cateId)
      this.setData({
      bookList0:this.data.bookList0.concat(res.data),
      booklen:lens+5
      })
    })
    .catch(res=>{
      console.log('请求失败',res)
    })
},
  //跳转到详情页面
   navigateTo:function(e){
     console.log(e)
     wx.navigateTo({
       url: '/pages/bookdetail/bookdetail?id='+e.currentTarget.dataset.id,
     })
 },
 listTotal(e){
   console.log("e=",e)
   var that=this
   if(e==0){
    wx.cloud.database().collection('books').count({
      success: function (res) {
        console.log("res.total=",res.total)
        that.setData({
             total: res.total
     })
     console.log("this.total=",that.data.total)
     }
    })
   }
   else {
     wx.cloud.database().collection('books')
     .where({
       classifyId:e
     }).count({
      success: function (res) {
        console.log("res.total=",res.total)
        that.setData({
             total: res.total
     })
    }
  })
  }
 },
 //更换顶部轮播图active状态
changeCate:function(e){
      console.log(e)
     let cateid=e.target.dataset.id
     this.setData({
       cateId:e.target.dataset.id
     })
    console.log(e.target.dataset.id),
     wx.showToast({
       title: '加载中...',icon:'loading',duration:500
     }),
     this.setlist(cateid)
     this.listTotal(cateid)
},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
     if(options.id!=0&&options.id!=null){
       console.log('导航跳转到了',options.id);
         console.log('原来的cateId是',this.data.cateId);  
          this.setData({
            cateId:options.id
          });
         console.log("cateId变成了",this.data.cateId);
         this.setlist(this.data.cateId)
         this.listTotal(this.data.cateId)
      }else if(options.id==null){
         console.log('我被打印了,cateId是',this.data.cateId)
         this.setlist(this.data.cateId)
         this.listTotal(this.data.cateId)
      }
      else{
        console.log("cateId是",this.data.cateId)
        this.setlist(this.data.cateId)
        this.listTotal(this.data.cateId)
      }
},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
      //用于设置滑动视图的宽高
      wx.getSystemInfo({
        success: (res) => {
          console.log(app.globalData)
          var i = app.globalData.currentLocation;
          this.setData({
             windowHeight:res.windowHeight,
             windowWidth:res.windowWidth,
             cateId:i
          })
        },
      })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.showNavigationBarLoading({
            
    })
    setTimeout(function(){
     wx.hideNavigationBarLoading({
     })
    },2000)
    this.setlist(this.data.cateId)
  }, 

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    console.log("lens=",this.data.booklen)
    console.log("total=",this.data.total)
    let len=this.data.booklen
    let total=this.data.total
   if(len<total){
    console.log("触底")
    wx.showLoading({
      title: '加载中',
    })
    setTimeout(function(){
        wx.hideLoading({
        })
    },1000)
    this.setlist(this.data.cateId)
   }else {
     wx.showToast({
       title: '到底啦',
       icon:"none",
       duration:1000
     })
     
   }
 
    
},
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})