// pages/myself/myself.js
const app= getApp()
Page({

  /**
   * 页面的初始数据
   */
  DB_NAME:{
    db_admin:"admin",
    db_user:"user"
  },
  data: {
    userInfo: {},
    hidden_actionSheet: true,
    categoryContents:[
      {name:'分享',imgsrc:'../../images/share.png',type:'share'},
      {name:'反馈',imgsrc:'../../images/feedback.png',type:'feedback'},
      {name:'客服',imgsrc:'../../images/custom.png',type:'contact'},
    ],
    settings:[
      {icon:'../../images/shoucang.png',text:'收藏',path:'../collection/collection',},
      // {icon:'../../images/feel.png',text:'近期心得',path:'../info/info',},
      {icon:'../../images/aboutus.png',text:'关于我们',path:'../aboutus/aboutus',},
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
    var that = this
    console.log("app.globalData.openid",app.globalData.openid)
    if(app.globalData.userInfo == null ){
    that.isAuthorize()
    .then(res => { //用户已经授权获取头像昵称
      //获取头像昵称
      console.log("userinfo",res.userInfo)
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          that.setData({
            userInfo: app.globalData.userInfo,
          })
        }
      })
    }).catch(res => { //用户没有授权获取头像昵称
      console.log("用户还未登录")
      that.setData({
        hidden_actionSheet: false,
      })
    })
  } else {
         this.setData({
           userInfo:app.globalData.userInfo,
           hidden_actionSheet:true
         })

   }
  },
 /**
   * 是否授权获取头像和昵称，已经授权返回到then，没有授权返回到catch
   */
  isAuthorize() {
    return new Promise((resolve, reject) => {
      // 获取用户信息
      wx.getSetting({
        success: res => {
          if (res.authSetting['scope.userInfo']) {
            console.log("全局--用户已经授权")
            resolve()
          } else {
            console.log("全局--用户还没有授权获取昵称和头像")
            reject()
          }
        }
      })
    })
  },

  //点击头像----事件
  bindViewTap: function () {
    console.log("点击了头像")
    //表示未登录
    if(this.data.userInfo.nickName=="微信用户"){
    this.setData({
      hidden_actionSheet:!this.data.hidden_actionSheet
    })
   }
  },
  // 点击了取消
  actionSheetChange: function (e) {
    var that=this
    console.log("点击了取消")
    this.setData({
      hidden_actionSheet: true
    })
    wx.showModal({
      content: '部分功能需要登录才能使用',
    })
    wx.getUserInfo({
      success: res => {
        console.log("res",res.userInfo)
        app.globalData.userInfo = res.userInfo
        that.setData({
          userInfo: app.globalData.userInfo,
        })
      }
    })
  },

  // 用户选择  拒绝还是接受都会进入这里
  getUserInfo: function (e) {
    var that=this;
    console.log("这是getuserinfo",e.detail.userInfo)
    // console.log("权限选择了：", e.detail)
    if (e.detail.rawData) { //权限选择了：允许
      console.log("权限选择了：允许",e.detail.rawData)
      //  app.globalData.userInfo = res.userInfo
      app.globalData.userInfo=e.detail.userInfo
      console.log(app.globalData.userInfo)
      that.setData({
        userInfo: app.globalData.userInfo,
        hidden_actionSheet: true // 隐藏actionSheet
      })
      wx.cloud.callFunction({
       name:'getopenid',
       success(res){
          app.globalData.openid=res.result.openid
       }
     })
    this.isNewUser()
    } else { //权限选择了：拒绝
      console.log("权限选择了：拒绝")
      wx.showModal({
        content: '部分功能需要登录才能使用',
      })
      wx.getUserInfo({
        success: res => {
          console.log("res",res.userInfo)
          app.globalData.userInfo = res.userInfo
          that.setData({
            userInfo: app.globalData.userInfo,
          })
        }
      }) 
    }
    

   
    
    // this.setData({
     
    // })

  },
  //判断是否为新用户
  isNewUser:function(){
    var user_info=this.data.userInfo
    console.log('这是user_info',user_info)
    //通过openid获取admin表中的数据
    this.getDBPromise({
         db_name:'user',
         entity:{
            openId:user_info.openId
         }
    }).then(res=>{
         var userInfo={
           nickName:null,
           avatarUrl:null,
           openId:null,
           lastLoginTime:"" + new Date().getTime(),
           status:1,
           collection:[]
         };
       if(res.data.length==0)    //是新用户，给新用户添加记录
       {
         //获取用户信息
         userInfo.nickName=user_info.nickName;
         userInfo.avatarUrl=user_info.avatarUrl;
         userInfo.lastLoginTime = new Date().getTime() + "";
         userInfo.openId =user_info.openId;
         userInfo.status=1;
         userInfo.collection=[];
         //添加新用户信息
         wx.cloud.database().collection(this.DB_NAME.db_user).add(
           {
             data:userInfo
           }
         ).then(res=>{
                 wx.hideLoading();
                 wx.showToast({
                   title:'登录成功',icon:'success',});
                   setTimeout(wx.switchTab,500,({url:"/pages/index/index",}))
         });
       }else{
         userInfo=app.globalData.userInfo=res.data[0];
         //更新用户信息
         userInfo.lastLoginTime =new Date().getTime() + "";
         wx.cloud.init();
         wx.cloud.database().collection(this.DB_NAME.db_user).doc(
           userInfo._id
         ).update({
           data:{
             lastLoginTime:userInfo.lastLoginTime,
             nickName:userInfo.nickName,
             avatarUrl:userInfo.avatarUrl
           }
         }).then(res=>{
           //用户信息更新成功
         }).catch(err=>{
           console.log("update:" + err);
         });
         wx.hideLoading();
         wx.showToast({
           title: '登录成功',icon:'success',
         });
        //  setTimeout(wx.switchTab,500,({url:"/pages/index/index",}));
       }   
    }).catch(err=>{
      console.log("getDBPromise:" + err);
    })    
  },
//数据库查询操作 
  getDBPromise:function(e){
   var db_name =e.db_name;
   var entity =e.entity;
   const db =wx.cloud.database();
   return db.collection(db_name).where(entity).get();
},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if(app.globalData.openid !=null){
      this.setData({
         userInfo:app.globalData.userInfo
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})