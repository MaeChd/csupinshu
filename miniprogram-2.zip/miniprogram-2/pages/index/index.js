

// pages/index/index.js
const app=getApp()//获取小程序实例
Page({

  /**
   * 页面的初始数据
   */
  swiperchange:function()
  {

  },
  navigateTo1(e)
  {
    app.globalData.currentLocation=e.currentTarget.dataset.id;
      wx.navigateTo({
        url: '../classify/classify?id='+e.currentTarget.dataset.id,
      })
      console.log('点击了',e.currentTarget.dataset.id)
  },
  data:
  {
      loading:true,//骨架屏是否显示
      username:'',
      indicatorDots:true,
      autoplay:true,
      current:0,
      interval:3000,
      duration:1000,
      circular:true,
      images:[],
      recommend:[],
      categoryContents:[
        {name:'心理',imgsrc:'../../images/xinlixue.png',id:1},
        {name:'社会',imgsrc:'../../images/shehui.png',id:2},
        {name:'历史',imgsrc:'../../images/lishi.png',id:3},
        {name:'哲学',imgsrc:'../../images/zhexue.png',id:4},
        {name:'科学',imgsrc:'../../images/kexue.png',id:5},
        {name:'经济',imgsrc:'../../images/jingji.png',id:6},
        {name:'其他',imgsrc:'../../images/other.png',id:7},
        {name:'全部',imgsrc:'../../images/all.png',id:0},
      ],
  },
  navigateTo:function(e){
    console.log(e)
    wx.navigateTo({
      url: '../bookdetail/bookdetail?id='+e.currentTarget.dataset.id,
    })
   },
   navigateTo2:function(e){
    console.log(e)
    wx.navigateTo({
      url: '../bookdetail/bookdetail?id='+e.currentTarget.dataset.id,
    })
   },
  // 获取用户信息
  onGetOpenid:function(){
         //调用云函数
         wx.cloud.callFunction({
                 name:'login',
                 data:{ },
                 success:res=>{
                     console.log('[云函数][login]user openid: ',res.result.openid)
                     app.globalData.openid =res.result.openid
                     wx.navigateTo({
                       url: '../userConsole/userConsole',
                     })
                 },
                 fail:err=>{
                   console.error('[云函数][login]调用失败',err)
                   wx.navigateTo({
                     url: '../deployFunctions/deployFunctions',
                   })
                 } 
           })
  },
  //获取小程序用户的openid
  getopenid(){
      wx.cloud.callFunction({
        name:'getopenid'
      }).then(res=>{

        console.log("获取成功",res.result.openid)
      }).catch(res=>{
        console.log("获取失败",res)
      })
  },
  //数据库查询
  getdb(){
     wx.cloud.database().collection('user').get()
     .then(res=>{
       console.log('查询成功',res)
     })
     .catch(res=>{
       console.log('查询失败',res)
     })
  },
  //云函数获取数据库
  cloudgetdb(){
      wx.cloud.callFunction({
        name:'cloudgetdb'
      })
      .then(res=>{
        console.log('云函数获取数据库成功',res)
      })
      .catch(res=>{
        console.log('云函数获取数据库失败',res)
      })
  },
  cloudUploadimg(){
    let that=this
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success (res) {
        // tempFilePath可以作为img标签的src属性显示图片
        console.log(res.tempFilePaths)
        that.uploadfile(res.tempFilePaths)
      }
    })
  },
  uploadfile(fileUrl){
    wx.cloud.uploadFile({
      cloudPath:'test.png',
      filePath: "" +fileUrl,
      success :res=>{
        const data = res.data
        //do something
        console.log('成功上传',res)
      },
      fail:res=>{
        console.log('上传失败',res)
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    app.getOpenId()
    wx.cloud.database().collection('books')
    .where({
      hot:true
    })
    .get()
    .then(res=>{
      console.log('热门请求成功',res)
      this.setData({
         images:res.data
      })
    })
    .catch(res=>{
      console.log('热门请求失败',res)
    })
    wx.cloud.database().collection('books')
    .where({
      recommand:true
    })
    .get()
    .then(res=>{
      console.log('推荐获取成功',res)
      this.setData({
        recommend:res.data
      })
    })
    .catch(res=>{
      console.log('推荐获取失败',res)
    })
    let username=app.globalData.userInfo;
        this.setData({
          username,
          loading:false   // 骨架屏隐藏
        })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
           wx.showNavigationBarLoading({
            
           })
           setTimeout(function(){
            wx.hideNavigationBarLoading({
            })
           },2000)
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  //转发到朋友圈
  onShareTimeline()
  {

  }
})