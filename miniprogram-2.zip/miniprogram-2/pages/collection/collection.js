// pages/collection/collection.js

const app = getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        collectionList:[],
        collectUrl:"../../images/collected.png",
    },

    /**
     * 生命周期函数--监听页面加载
     */
    getCollection(){
        var openid = app.globalData.openid
        wx.cloud.database().collection('user')
        .where({
             _openid: openid
        })
        .get()
        .then(res=>{
            console.log(res)
            var collection = res.data[0].collection
            this.setData({
                collectionList:collection,
            })
   
        })
    },
    onLoad: function (options) {
    //  if(app.globalData.userInfo == null)
    //  {
    //      wx.showToast({
    //        title: '您还未登录',
    //        icon:'error'
    //      })
    //      wx.navigateBack({})
    //  }
    //  else{
        var openid = app.globalData.openid
        wx.cloud.database().collection('user')
        .where({
             _openid: openid
        })
        .get()
        .then(res=>{
            console.log(res)
            var collection = res.data[0].collection
            this.setData({
                collectionList:collection,
            })
   
        })
    //  }
    },
    //点击进入详情页面
    goToDetail(e){
         console.log(e)
         console.log(e.currentTarget.dataset.id)
         var id=e.currentTarget.dataset.id
         wx.navigateTo({
           url: '../bookdetail/bookdetail?id='+id,
         })
    },

    //取消收藏
    delete(e){
        console.log(e)
        var openid=app.globalData.openid
        var index =e.currentTarget.dataset.index
        var that = this 
        wx.showModal({
          title:'提示',
          content:'是否取消收藏',
          success (res) {
            if (res.confirm) {
              console.log('用户点击确定')
              wx.cloud.database().collection('user')
              .where({
                  _openid:openid
              })
              .get()
              .then(res=>{
                   console.log(res)
                   var collection = that.data.collectionList
                   collection.splice(index,1)
                   wx.cloud.database().collection('user')
                   .where({
                       _openid:openid
                   })
                   .update({
                       data:{
                           collection:collection
                       },
                       success(res){
                           wx.showToast({
                             title: '取消收藏成功',
                           })
                           that.getCollection()
                       }
                   })
                   
              })
            
            } else if (res.cancel) {
              console.log('用户点击取消')
             
            }
          }
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    }, 

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})