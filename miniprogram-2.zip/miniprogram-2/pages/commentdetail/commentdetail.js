// pages/commentdetail/commentdetail.js
const util = require("../../utils/util")
const app = getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
          commentAction:{},//获取云数据库中的这条评论详情
          commentList:{},//获取云数据库中的评论列表
          inputValue:"",//获取实时评论内容
          placeHolder:'发布一条评论吧',
          toNickname:"",
          toOpenid:"",
          myOpenid:"",//用户个人的openid
          id:"" //页面内容在云数据库中的id
    },
   //用户登录
   logIn(){
      //提示先授权登录，才能发表评论
      wx.showModal({
        title: '提示',
        content: '您还未登录，请先登录',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
            wx.navigateTo({
            url: '../auth/auth',
          })
          } else if (res.cancel) {
            console.log('用户点击取消')
            wx.showModal({
              content: '部分功能需要登录才能使用',
            })
          }
        }
      })
   },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
          var openid=app.globalData.openid
          console.log(options.id)
          this.setData({
            id:options.id,
            myOpenid:openid
          })
          this.getDetail()
    },
    //获取回复详情
    getDetail(){
      var openid=app.globalData.openid
      wx.cloud.database().collection('actions')
      .doc(this.data.id)
      .get()
      .then(res=>{
          console.log(res)
           //格式化时间
            var action =res.data 
            action.time =util.formatTime(new Date(action.time))
            for(var l in action.prizeList){
              if(action.prizeList[l].openid == app.globalData.openid)
              {
                 action.isPrized = true
                 break
              }
            }
            for(var l in action.commentList){
              action.commentList[l].time = util.formatTime(new Date(action.commentList[l].time))
            }
          this.setData({
             commentAction:res.data,
             openid:openid
          })
      })
    },
    //是否点赞
    Ifdianzan(){
      var id =this.data.id
      if(app.globalData.userInfo == null){
          this.logIn()
          
      }else {
        console.log(this.data.id)
        var that=this
        wx.cloud.database().collection('actions')
        .doc(id)
        .get()
        .then(res=>{
             var action = res.data
             var tag = false
             var index 
             for(var l in action.prizeList){
               if(action.prizeList[l].openid == app.globalData.openid){
                tag = true
                index=l
                break
               }
             }
            if(tag){
              //之前已点赞  删除点赞记录
               action.prizeList.splice(index,1)
               wx.cloud.database().collection('actions')
               .doc(id)
               .update({
                    data:{
                         prizeList:action.prizeList
                   },
                   success(res){
                     console.log(res)
                     that.getDetail()
                   }
               })
            }else {
             //之前未点赞 添加点赞记录
             var user ={}
             user.nickName = app.globalData.userInfo.nickName
             user.openid=app.globalData.openid
             action.prizeList.push(user)
  
             wx.cloud.database().collection('actions')
             .doc(id)
             .update({
                data:{
                  prizeList:action.prizeList
                },
                success(res){
                  console.log(res)
                  wx.showToast({
                    title: '点赞成功!',
                  })
                  that.getDetail()
                }
             })
            }  
        })
        .catch(res=>{
          console.log('点赞数据获取失败')
        })
    
      }
      
    },
  //用户删除自己的评论
   delete(){
    wx.cloud.database().collection('actions')
    .doc(this.data.id)
    .remove()
    .then(res=>{
      console.log('成功删除',res)
      
      wx.navigateBack({
         success(res){
            wx.showToast({
                title: '删除成功',
              })
         }
      })
    }).catch(res=>{
      console.log('删除失败',res)
    })
  },
  getInputValue(e){
     console.log(e.detail.value)
     this.data.inputValue = e.detail.value
     
  },
  //发表评论
   publishComment(){
    var id =this.data.id
    if(app.globalData.userInfo == null){
       this.logIn()
    }else {
      if(this.data.inputValue == ''){
           wx.showToast({
             title: '你还没有评论哟',
             icon:'error'
           })
      }else {
      console.log(this.data.id)
      var that=this
      wx.cloud.database().collection('actions')
      .doc(id)
      .get()
      .then(res=>{
           var action = res.data
           var comment={}
           comment.nickName = app.globalData.userInfo.nickName
           comment.openid=app.globalData.openid
           comment.faceImg = app.globalData.userInfo.avatarUrl
           comment.text = this.data.inputValue
           comment.time =Date.now()
           comment.toOpenid = this.data.toOpenid
           comment.toNickname = this.data.toNickname
           action.commentList.push(comment)
           wx.cloud.database().collection('actions')
           .doc(id)
           .update({
                data:{
                  commentList:action.commentList
                },
                success(res){
                   console.log(res)
                   wx.showToast({
                     title: '评论成功',
                   })
                   that.getDetail()
                   that.setData({
                     inputValue:"",
                     placeHolder:'发布一条评论吧'
                   })
                }

           })


      }).catch(res=>{

      })
     }
    }

   },
   //用户删除自己的评论（评论列表）
   deleteComment(e){
    if(app.globalData.userInfo == null){
      this.logIn()
       
    }else{
      console.log(e.currentTarget.dataset.index)
      var that =this 
      wx.showModal({
        title: '提示',
        content: '是否删除该条评论',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
            var id = that.data.id
            var index = e.currentTarget.dataset.index
            wx.cloud.database().collection('actions')
            .doc(id)
            .get()
            .then(res=>{
                console.log(res)
                var action =res.data
                action.commentList.splice(index,1)

                wx.cloud.database().collection('actions')
                .doc(id)
                .update({
                    data:{
                        commentList:action.commentList
                     },
                    success(res){
                      wx.showToast({
                        title: '删除成功',
                      })
                      that.getDetail()
                    }
                  })
              }).catch(res=>{

               })
          
          } else if (res.cancel) {
            
          }
        }
      })
    }
  },
  //回复评论
  hfComment(e){
     if(app.globalData.userInfo == null ){
       this.logIn()
     }else {
         console.log(e.currentTarget.dataset.index)
         var index = e.currentTarget.dataset.index
         var comList=this.data.commentAction.commentList[index]
         this.setData({
           placeHolder: '回复'+comList.nickName,
           toOpenid:comList.openid,
           toNickname:comList.nickName,
         })
     }
  },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})