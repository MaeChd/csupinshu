const App = getApp()
var id=""
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    // 自定义顶部导航
    navHeight: App.globalData.navHeight,
    navTop: App.globalData.navTop,
    // 图标
    leftIcon: "../../../../images/back.png",
    searchIcon: "../../../../images/search.png",
    eyeIconOne: "../../../../images/eyeone.png",
    eyeIcon: "../../../../images/eye.png",
    upperLeftArrow: "../../../../images/rightArrow.png",
    recommend: [ //热门推荐
      
    ],
    historyStorage: [],        //历史搜索
    historyStorageShow: false,
    falg: true,         //换一批
    hotsearch1: [{ title: "平凡的世界" }, { title: "追风筝的人" }],
    hotsearch2: [{ title: "白岩松" }, { title: "许嵩" }],
    // searchresult: false,
    inputValue: "",        //输入框输入的值
    replaceValue: "",     //替换输入框的值
    eye: true,        //显示隐藏
    searchresult: false,
    searchResult: []//虚拟的查询结果，元素形式为键值对{result：""}
  },
  // 点击返回上一级
  goBack: function() {
    let pages = getCurrentPages();      //获取小程序页面栈
    let beforePage = pages[pages.length - 2];       //获取上个页面的实例对象
    beforePage.setData({
      txt: "修改数据了"
    })
    beforePage.goUpdate();           //触发上个页面自定义的go_update()方法
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 获取顶部固定高度
   */
  attached: function() {
    this.setData({
      navHeight: App.globalData.navHeight,
      navTop: App.globalData.navTop,
    })
  },
  /**
   * 换一批操作
   */
  changeother: function () {
    this.setData({
      falg: !this.data.falg
    })
  },
 
  /**
   * 热门搜索显示隐藏
   */
  reye: function () {
    this.setData({
      eye: !this.data.eye
    })
  },
 
  /**
   * 清除最近搜索
   */
  remove: function () {
    var _this = this
    wx: wx.showModal({
      content: '确认清除所有历史记录?',
      success: function (res) {
        if (res.confirm) {
          wx: wx.removeStorage({
            key: 'historyStorage',
            success: function (res) {
              _this.setData({
                historyStorage: []
              })
              wx.setStorageSync("historyStorage", [])
            },
          })
        } else {
          console.log("点击取消")
        }
      },
    })
  },
 
 
  /**
   * 获取input的值
   */
  getInputValue(e) {
     console.log("获取value值",e.detail)   // {value: "ff", cursor: 2}
    this.setData({
      inputValue: e.detail.value
    })
    this.setData({
      searchresult: true,
    })
  },

  /**
   * 点击搜索提交跳转并存储历史记录
   */
  searchbegin: function (e) {
    let _this = this
    var data = e.currentTarget.dataset;
    console.log(data)
    _this.data.replaceValue = e.currentTarget.dataset.postname
    // _this.data.replaceValue = 
    //includes方法查询数组中是否有当前元素，有则不添加
    if(_this.data.historyStorage.includes(data.postname)!=true){
    wx: wx.setStorage({
      key: 'historyStorage',
      data: _this.data.historyStorage.concat(_this.data.inputValue),
      data: _this.data.historyStorage.concat(_this.data.replaceValue)
    })
  }
     console.log(_this.data.inputValue)
     console.log(_this.data.historyStorage)
    console.log(e)
    if(this.data.inputValue!=""){
      wx.cloud.database().collection('books')
      .where({
        book_name:this.data.inputValue
      })
      .get()
      .then(res=>{
        console.log('获取成功',res.data)
        id=res.data[0]._id
        console.log(id)
        if(id!=""){
          wx.navigateTo({
            url: '../../../bookdetail/bookdetail?id='+id,
          })
          }
          else{
            wx.showToast({
              title: '很抱歉，未找到',
              icon:"error"
            })
          }
      })
      .catch(res=>{
        wx.showToast({
          title: '很抱歉，未找到',
          icon:"error"
        })
        console.log("获取失败",res)
      })
    }
  },
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    // 历史搜索
    let that = this
    wx.getStorage({
      key: 'historyStorage',
      success: function (res) {
        console.log(res.data)
        that.setData({
          historyStorageShow: true,
          historyStorage: res.data
        })
      }
    })
    //以热门请求作为第一个
    wx.cloud.database().collection('books')
    .where({
      hot:true
    })
    .limit(5)//限制只返回热门中的前五条,后期继续完善
    .get()
    .then(res=>{
      console.log("热门请求成功")
      console.log(res.data)
      this.setData({
        hotsearch1:res.data
      })
    })
    wx.cloud.database().collection('books')
    .where({
      recommand:true
    })
    .limit(5)
    .get()
    .then(res=>{
      console.log("推荐请求成功")
      console.log(res.data)
      this.setData({
        hotsearch2:res.data
      })
    })

    
  },
  //点击进入详情页
  goToList: function (e) {
      
  },
  goUpdate: function() {
    this.onLoad()
    console.log("我更新啦")
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
 
  },
 
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
 
  },
 
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {
 
  },
 
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
 
  },
 
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
 
  },
 
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
 
  },
 
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {
 
  }
})