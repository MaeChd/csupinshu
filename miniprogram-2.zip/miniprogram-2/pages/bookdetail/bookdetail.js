// const { delete } = require("request-promise");
// pages/bookdetail/bookdetail.js
const app=getApp()
const util = require("../../utils/util")
const Audio = wx.createInnerAudioContext();
const db=wx.cloud.database();
// let collect=false;
// let ID="";
let viewcounts="";
// let openid="";
let collectionNow=[]

Page({

  /**
   * 页面的初始数据
   */
  data: {
    windowHeight:"",//滑动视图高度
    actionsList:{},//列表评论
    inputValue:"",
    placeHolder:'发一条友善的评论吧',
    myOpenid:"",//用户的openid
    ID:"",//数据的_Id 
    collect:false,//用户是否收藏
    bookname:"",//数据名称
    collectUrl:false,
    playclass:1,
    currentTab: 0,
    isActive:false,
    showTime1:'00:00',
    showTime2:'00:00',
    audioSeek:0,//进度条时间点
    audioDuration: 0,//进度条总长度
    audioTime:0,//进度条当前长度
    current:{},//获取书籍所有数据
    audiosrc:{}
  },
  
  //生成随机颜色
  getRandomColor() {
    const rgb = []
    for (let i = 0; i < 3; ++i) {
      let color = Math.floor(Math.random() * 256).toString(16)
      color = color.length === 1 ? '0' + color : color
      rgb.push(color)
    }
    return '#' + rgb.join('')
  },

  //点击是否收藏
  ifCollect(){
    //点击收藏，存储的字段有 ：该数据的id，海报，简介，bookname，收藏时间
     if(app.globalData.userInfo == null ){
       this.logIn()
     }else {
        //获取用户信息
        var openid=app.globalData.openid
        var id = this.data.ID
        var that= this
        wx.cloud.database().collection('user')
        .where({
          _openid:openid
        })
        .get()
        .then(res=>{
            console.log("res",res.data)
            var collection = res.data[0].collection
            var tag=false
            var index
            console.log(res.data[0].collection)
            for(var l in collection){
               if(collection[l].bookid == id){
                    tag = true
                    index = l
                    break
               }
            }
            if(tag){
              //之前已收藏  删除收藏记录
             collection.splice(index,1)
             wx.cloud.database().collection('user')
             .where({
               _openid:openid
             })
             .update({
                  data:{
                       collection:collection
                 },
                 success(res){
                   console.log(res)
                   that.setData({
                     collectUrl:false
                   })
                 }
             })
            }else {
              //点击收藏，存储的字段有 ：该数据的id，海报，简介，bookname，收藏时间
               var bookdetail={}
               bookdetail.bookid = id
               bookdetail.bookName=this.data.bookname
               bookdetail.bookAuthor=this.data.current.book_author
               bookdetail.description=this.data.current.book_description
               bookdetail.iconUrl=this.data.current.iconUrl
               bookdetail.collTime=Date.now()
               collection.push(bookdetail)

               wx.cloud.database().collection('user')
               .where({
                 _openid:openid
               })
               .update({
                 data:{
                   collection:collection
                 },
                 success(res){
                     wx.showToast({
                       title: '收藏成功',
                     })
                    that.setData({
                      collectUrl:true
                    })
                 }
               })
            }
        }).catch(res=>{

        })

     }
},

  Initialization(){//初始化，获取音频播放时长
    var t=this;
    console.log(this.data.audiosrc)
    if (this.data.audiosrc.length != 0) {
      //设置src
      Audio.src = this.data.audiosrc;
      //运行一次
      //  Audio.play();
      //  Audio.pause();
      Audio.onCanplay(() => {
        //初始化duration
        Audio.duration
        setTimeout(function () {
          //延时获取音频真正的duration
          var duration = Audio.duration;
          var min = parseInt(duration / 60);
          var sec = parseInt(duration % 60);
          if (min.toString().length == 1) {
            min = `0${min}`;
          }
          if (sec.toString().length == 1) {
            sec = `0${sec}`;
          }
          t.setData({ audioDuration: Audio.duration, showTime2: `${min}:${sec}` });
        }, 1000)
      })
    }
},
  //拖动进度条事件
  sliderChange(e) {
    var that = this;
    Audio.src = this.data.current.audioSrc;
    //获取进度条百分比
    var value = e.detail.value;
    this.setData({ audioTime: value });
    var duration = this.data.audioDuration;
    //根据进度条百分比及歌曲总时间，计算拖动位置的时间
    value = parseInt(value * duration / 100);
    //更改状态
    this.setData({ audioSeek: value, isActive: true ,
       showTime1: this.formatTime(value)
      });
    //调用seek方法跳转歌曲时间
    Audio.seek(value);
    //播放歌曲
    Audio.play();
  },
  formatTime: function (s) {//时间显示标准化
    let t = '';
    s = Math.floor(s);
    if (s > -1) {
    let min = Math.floor(s / 60) % 60;
    let sec = s % 60;
    if (min < 10) {
     t += "0";
    }
     t += min + ":";
    if (sec < 10) {
    t += "0";
    }
    t += sec;
    }
    return t;
  },

  loadaudio() {
    clearInterval(this.data.durationIntval);
    var that = this;
    //设置一个计步器
    this.data.durationIntval = setInterval(function () {
      //当歌曲在播放时执行
      if (that.data.isActive == true) {
        //获取歌曲的播放时间，进度百分比
        var seek = that.data.audioSeek;
        var duration = Audio.duration;
        var time = that.data.audioTime;
        time = parseInt(100 * seek / duration);
        //当歌曲在播放时，每隔一秒歌曲播放时间+1，并计算分钟数与秒数
        var min = parseInt((seek + 1) / 60);
        var sec = parseInt((seek + 1) % 60);
        //填充字符串，使3:1这种呈现出 03：01 的样式
        if (min.toString().length == 1) {
          min = `0${min}`;
        }
        if (sec.toString().length == 1) {
          sec = `0${sec}`;
        }
        var min1 = parseInt(duration / 60);
        var sec1 = parseInt(duration % 60);
        if (min1.toString().length == 1) {
          min1 = `0${min1}`;
        }
        if (sec1.toString().length == 1) {
          sec1 = `0${sec1}`;
        }
        //当进度条完成，停止播放，并重设播放时间和进度条
        if (time >= 100) {
          that.play();
          that.setData({ audioSeek: 0, audioTime: 0, audioDuration: duration, isAcitve: false, showTime1: `00:00` });
          return false;
        }
        //正常播放，更改进度信息，更改播放时间信息
        that.setData({ audioSeek: seek + 1, audioTime: time, audioDuration: duration, showTime1: `${min}:${sec}`, showTime2: `${min1}:${sec1}` });
      }
    }, 1000);
  },
  play() {
    var that=this;
    //获取播放状态和当前播放时间
    var isActive = this.data.isActive;
    var seek = this.data.audioSeek;
    // 
    //更改播放状态
    this.setData({ isActive: !isActive })
    if (isActive) {
      //如果在播放则记录播放的时间seek，暂停
      this.setData({ audioSeek: Audio.currentTime });
      Audio.pause();
    } else {
      //如果在暂停，获取播放时间并继续播放
      Audio.src = this.data.current.audiosrc;
      if (Audio.duration != 0) {
        this.setData({ audioDuration: Audio.duration });
      }
      //跳转到指定时间播放
      Audio.seek(seek);
      that.loadaudio();
      Audio.play();
    }
  },
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      
      var that = this 
      setTimeout(function(){
        //获取用户的openid
        console.log("此用户的openid是",app.globalData.openid)
        that.setData({
          myOpenid:app.globalData.openid
        })
      }, 2000);
    
      console.log("options",options)
      var ID=options.id
      //获取书的详情
      wx.cloud.database().collection('books')
      .doc(ID)
      .get()
      .then(res=>{
          console.log("数据详情获取成功",res.data)
          //音频视频都有的
          if(res.data.audioSrc!=""&&res.data.videoSrc!=""){
          this.setData({
              playclass:2,
              current:res.data,
              audiosrc:res.data.audioSrc,
              bookname:res.data.book_name,
              ID:res.data._id 
           })
          }
        //只有视频的
        else if(res.data.audioSrc==""){
           this.setData({
              playclass:1,
              current:res.data,
              currentTab:1,
              bookname:res.data.book_name,
              ID:res.data._id
           })
        }
        //只有音频的
        else if(res.data.videoSrc==""){
          this.setData({
            playclass:0,
            currentTab:0
          })
        }
        viewcounts=res.data.view_counts;
        viewcounts+=1;
        wx.cloud.callFunction({
          name:"cloudfeel",
          data:{
            choose:"viewcounts",
            id:ID,
            view_counts:viewcounts
          }
        })
        console.log(this.data.current)
        console.log(this.data.audiosrc)
        this.Initialization();
    })
    .catch(res=>{
         console.log('数据详情获取失败',res)
    })
   
    console.log("ID是",ID)
      // 获取评论列表
      wx.cloud.database().collection('actions')
      .where({
        bookId:ID
      })
      .orderBy('time','desc')
      .get()
      .then(res=>{
        //格式化时间
        var list =res.data 
        for(var l in list){
          list[l].time = util.formatTime(new Date(list[l].time))
        }
        for(var l in list){
          for(var j in list[l].prizeList){
            if(list[l].prizeList[j].openid == app.globalData.openid){
              list[l].isPrized = true
            }
          }
        }
        console.log("评论列表数据获取成功",res)
        this.setData({
          actionsList:list
        })
      }).catch(res=>{
          console.log("评论列表数据获取失败",res)
      })
        // 匹配 收藏
        var openid = app.globalData.openid
        wx.cloud.database().collection('user')
        .where({
            _openid:openid
        })
        .get()
        .then(res=>{
            console.log("这是一个res.data[0]",res.data[0])
            console.log('这是ID',ID)
            var data= res.data[0].collection
            for(var l in data){
              if(data[l].bookid == ID){
                console.log('我只是看看进来没')
                 this.setData({
                   collectUrl:true
                 })
                  break
              }
            }
        }).catch(res=>{

        })
      
  },
  //获取评论列表
  getActionList(){
    // console.log("此用户的openid是",app.globalData.openid)
    // that.setData({
    //   myOpenid:app.globalData.openid
    // })
    wx.cloud.database().collection('actions')
    .where({
      bookId:this.data.ID
    })
    .orderBy('time','desc')
    .get()
    .then(res=>{
      //格式化时间
      var list =res.data 
      for(var l in list){
        list[l].time = util.formatTime(new Date(list[l].time))
      }
      for(var l in list){
        for(var j in list[l].prizeList){
          if(list[l].prizeList[j].openid == app.globalData.openid){
            list[l].isPrized = true
          }
        }
      }

      for(var l in list){
        if(list[l].commentList.length != 0){
        for( var j in list[l].commentList){
          list[l].commentList[j].time =util.formatTime(new Date(list[l].commentList[j].time))
        }
       }
      }
      console.log("评论列表数据获取成功",res)
      this.setData({
         actionsList:list
      })
    }).catch(res=>{
        console.log("评论列表数据获取失败",res)
    })
  },
 // 获取用户输入
     
 getValue(e){
  console.log(e.detail.value)
  this.setData({
      inputValue:e.detail.value
  })
},


submitData(){
       console.log('app.globalData.userInfo',app.globalData.userInfo)
       if(app.globalData.userInfo == null){
            this.logIn()
       }
       else {
        if(this.data.inputValue == ''){
          wx.showToast({
            title: '你还没有评论哟',
            icon:'error'
          })
        }
        else {
          wx.showLoading({
            title: '发布中',
            mask:true
          })
          var that =this;
          wx.cloud.database().collection('actions').add({
              data:{
                  nickName:app.globalData.userInfo.nickName,
                  faceImg:app.globalData.userInfo.avatarUrl,
                  text:this.data.inputValue,
                  time:Date.now(),
                  bookId:this.data.ID,
                  bookname:this.data.bookname,
                  prizeList:[],
                  commentList:[]
              },
              success(res){
                  wx.hideLoading({
                    success: (res) => {},
                  })
                  console.log(res)
                  wx.showToast({
                    title: '发表成功',
                  })
                  that.getActionList()
                  that.setData({
                      inputValue:''
                  })
              }
           })
         }
      }
},

  goToDetail(e){
    console.log(e.currentTarget.dataset.id)
    wx.navigateTo({
      url: '../commentdetail/commentdetail?id='+e.currentTarget.dataset.id,
    })
  },

  deleteAction(e){
     console.log(e.currentTarget.dataset.id)

     wx.cloud.database().collection('actions')
     .doc(e.currentTarget.dataset.id)
     .remove()
     .then(res=>{
       console.log('成功删除',res)
       wx.showToast({
         title: '删除成功',
       })
       this.getActionList()
     }).catch(res=>{
       console.log('删除失败',res)
     })
  },
  
  //是否点赞
  Ifdianzan(e){
    if(app.globalData.userInfo == null){
      this.logIn()
      console.log("app.globalData.openid",app.globalData.openid)
    }else {
      // console.log("app.globalData.openid",app.globalData.openid)
      console.log(e.currentTarget.dataset.id)
      var id = e.currentTarget.dataset.id
      var that=this
      wx.cloud.database().collection('actions')
      .doc(id)
      .get()
      .then(res=>{
           var action = res.data
           var tag = false
           var index 
           
           for(var l in action.prizeList){
             if(action.prizeList[l].openid == app.globalData.openid){
              tag = true
              index=l
              break
             }
            }
            console.log("tag",tag)
           if(tag){
            //之前已点赞  删除点赞记录
             action.prizeList.splice(index,1)
             wx.cloud.database().collection('actions')
             .doc(id)
             .update({
                  data:{
                       prizeList:action.prizeList
                 },
                 success(res){
                   console.log(res)
                   that.getActionList()
                 }
             })
          }else {
           //之前未点赞 添加点赞记录
           var user ={}
           user.nickName = app.globalData.userInfo.nickName
           user.openid=app.globalData.openid
           action.prizeList.push(user)

           wx.cloud.database().collection('actions')
           .doc(id)
           .update({
              data:{
                prizeList:action.prizeList
              },
              success(res){
                console.log(res)
                wx.showToast({
                  title: '点赞成功!',
                })
                that.getActionList()
              }
           })
           
          }  
      })
      .catch(res=>{
        console.log('点赞数据获取失败')
      })
  
    }
    
  },
  logIn(){
    //提示先授权登录
    var that =this
      wx.showModal({
        title: '提示',
        content: '您还未登录，请先登录',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
            wx.navigateTo({
             url: '../auth/auth',
            
           })
          
          } else if (res.cancel) {
            console.log('用户点击取消')
            wx.showModal({
              content: '部分功能需要登录才能使用',
            })
          }
        }
      })
    
  },
  //用户删除评论
  deleteComment(e){
    if(app.globalData.userInfo == null){
      this.logIn()
       
    }else{
      console.log(e.currentTarget.dataset.id)
      console.log(e.currentTarget.dataset.index)
      var that =this 
      wx.showModal({
        title: '提示',
        content: '是否删除该条评论',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
            var id = e.currentTarget.dataset.id
            var index = e.currentTarget.dataset.index
            wx.cloud.database().collection('actions')
            .doc(id)
            .get()
            .then(res=>{
                console.log(res)
                var action =res.data
                action.commentList.splice(index,1)

                wx.cloud.database().collection('actions')
                .doc(id)
                .update({
                    data:{
                        commentList:action.commentList
                     },
                    success(res){
                      wx.showToast({
                        title: '删除成功',
                      })
                      that.getActionList()
                    }
                  })
              }).catch(res=>{

               })
          
          } else if (res.cancel) {
            
          }
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
   
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   //用于设置滑动视图的宽高
   console.log('app.globalData.openid是',app.globalData.openid)
   this.getActionList()
   wx.getSystemInfo({
    success: (res) => {
      console.log(res)
      console.log(app.globalData)
      // var i = app.globalData.currentLocation;
      this.setData({
         
         windowHeight:res.windowHeight,
         windowWidth:res.windowWidth,
        //  cateId:i
      })
    },
  })

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
     //卸载页面，清除计步器
     clearInterval(this.data.durationIntval);
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
      this.getActionList()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
   /**
   * 导航标签选择
   */
  swichNav: function (e) {
    console.log(e);
    var that = this;
    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current,
      })
    }
  },
  /**
   * 导航页面显示
   */
  swiperChange: function (e) {
    console.log(e);
    this.setData({
      currentTab: e.detail.current,
    })
  }
})